﻿# 修复版完整运行包

1. 本机已有数据库时，填写 config/backend.env，不要重置数据库。
2. 安装 Node 18+、JDK 17+、MySQL 8、Redis。新电脑首次初始化参阅 RUNBOOK。
3. 双击 start-mall.bat，访问 http://127.0.0.1:81/ 。管理端运行 start-admin-runtime.bat，访问 80 端口。
4. 包含后端 JAR、前后台生产构建和源码；不含本机密码、数据库副本、node_modules 或运行环境安装器。
5. 启动时自动增量升级三张表（收藏、偏好、支付幂等映射），保留旧数据。支付为沙箱。详细范围及验收见 docs/功能完善-v1.2.0.md。
