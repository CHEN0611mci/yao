# 萌宠优选 · 用户端交付包 v1.0.0

## 包含内容

- user-ui/src、public：Vue 3 用户端完整源码及静态资源。
- user-ui/dist：本次重新构建的生产静态文件。
- user-ui/package-lock.json：锁定依赖，使用 npm ci 安装。
- verify/user-ui：接口验收记录、浏览器验收记录、电脑及手机截图。
- docs：用户端详细设计。
- FILES.sha256：包内文件的 SHA-256 清单。

## 启动开发版

1. 需要 Node.js 18+（推荐 22），并先启动已有后端、MySQL 和 Redis。
2. 双击 start-user-ui.bat，首次会自动安装依赖。
3. 打开 http://127.0.0.1:81/ 。

默认后端 http://127.0.0.1:8080 。如需更改，复制 user-ui/.env.example 为 .env.local 并修改 VITE_API_TARGET。
演示会员：member1 / member123，或 member2 / member123（依赖已有后端种子数据）。

## 预览已构建版本

双击 preview-user-ui.bat，打开 http://127.0.0.1:4181/ 。
该方式直接使用包内 dist，不重新构建。仍需启动已有后端。

## 部署

把 user-ui/dist 的内容放到 Web 服务器静态目录，为 History 路由配置 index.html 回退，
将 /api/ 和 /profile/ 代理到后端。配置参考 deploy/nginx.example.conf。
不要直接双击 dist/index.html；需要通过 HTTP 服务访问。

## 验收与范围

已完成 18 条路由、商品与会员、购物车、结算、沙箱支付、订单、宠物、地址及消息。
已通过 53 项真实接口检查、4 项单元测试、Vue 页面编译和生产构建。
支付仅用于教学沙箱；种子商品图片缺失时显示明确的缺图插画。
本包是独立用户端交付包，不含后端服务、数据库数据或本机依赖目录。
后端项目来源：https://github.com/CHEN0611mci/yao 。
详细说明见 user-ui/README.md。
