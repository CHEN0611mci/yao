@echo off
cd /d "%~dp0user-ui"
if not exist node_modules call npm.cmd ci
if errorlevel 1 exit /b %errorlevel%
echo Preview: http://127.0.0.1:4181/
call npm.cmd run preview
